"""Apply completed lightweight-AI outputs to the portable game, using CSV filenames."""
import csv
import json
from pathlib import Path

base = Path(__file__).resolve().parent
with (base / "sd-generation-prompts.csv").open(encoding="utf-8-sig", newline="") as source:
    rows = list(csv.DictReader(source))
catalog = {}
for row in rows:
    path = Path(row["output_path"])
    target = base / path
    if not target.is_file():
        continue
    with target.open("rb") as handle:
        header = handle.read(12)
    if header[:4] != b"RIFF" or header[8:12] != b"WEBP":
        raise SystemExit(f"Invalid WebP: {path}")
    catalog[path.stem] = path.as_posix()
dest = base / "custom-art.js"
temporary = dest.with_suffix(".tmp")
temporary.write_text("window.GrailArtOverrides = "+json.dumps(catalog, ensure_ascii=True)+";\n", encoding="utf-8")
temporary.replace(dest)
print(f"Registered {len(catalog)} finished portraits.")
